/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.ifmg.sistemafinanceiro.model;
import java.util.ArrayList;
/**
 *
 * @author alunos
 */
interface ProdutoDAO {
    
    public int adicionar(ContatoBEAN contato);        
    public boolean excluir(int codigo);
    public ContatoBEAN listar(int codigo);
    public ArrayList<ContatoBEAN> listarTodos();
    public boolean editar(ContatoBEAN contato);
    
}
