/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.ifmg.sistemafinanceiro.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * fabrica de conexão - padrão factory
 */
public class ConnectionFactory {
    
    //singleton
    private static ConnectionFactory instance = new ConnectionFactory();
    
    //constante e static - para usar sempre a mesma referência
    public static final String URL = "jdbc:mysql://localhost:3306/XXXX";
    public static final String USER = "root"; //nome do usuario
    public static final String PASSWORD = ""; //senha
    public static final String DRIVER_CLASS = "com.mysql.cj.jdbc.Driver"; //nome do driver
    
    //construtor privado - padrão singleton - garantir unica instancia para todo o aplicativo
    private ConnectionFactory() {
        try {
            //registra o driver
            Class.forName(DRIVER_CLASS);
        } catch (ClassNotFoundException e) {
               System.err.println("ERRO: Driver não encontrado");
        }
    }
     
    private Connection createConnection() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(URL,
                                                  USER, PASSWORD);
            System.out.println("Banco de dados conectado com sucesso");
        } catch (SQLException e) {
            System.err.println("ERRO: Erro na conexão com o banco de dados");
        }
        return connection;
    }   
    
    public static Connection getConnection() {
        return instance.createConnection();
    }
    
}
